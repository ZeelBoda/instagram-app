package com.technicalinterview.instagramclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstagramcloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
